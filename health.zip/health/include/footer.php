<footer id="rs-footer" class="rs-footer">
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-12 col-sm-12 footer-widget md-mb-50">
                    <h4 class="widget-title">About Us</h4>
                    <p style="color: black; text-align: justify;">A Complete healthcare setup in India, might require lot of complex approvals from various department like muncipality, Lucknow, Hydrabad, Gorakhpur, Maharajganj. This might be congusing for people inexperienced with India health laws. This is where the service of Shifa Health Care & Multi-business Pvt Ltd. come in. We offer our service to healthcare facilities in the India.</p>
                </div>
                <div class="col-lg-3 col-md-12 col-sm-12 footer-widget md-mb-50">
                    <h4 class="widget-title">Quick Links</h4>
                    <ul class="site-map">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Clients</a></li>
                        <li><a href="#">Contact Us</a></li>

                    </ul>
                </div>
                <div class="col-lg-3 col-md-12 col-sm-12 footer-widget md-mb-50">
                    <h4 class="widget-title">Services</h4>
                    <ul class="site-map">
                        <li><a href="#">ICU Setup</a></li>
                        <li><a href="#">Medical Staff Solution</a></li>
                        <li><a href="#">Hospital Project Upgradation</a></li>
                        <li><a href="#">Doctor Services</a></li>
                        <li><a href="#">Medical Equipment</a></li>
                        <li><a href="#">NABL</a></li>
                        <!-- <li><a href="#">NABH</a></li>
                        <li><a href="#">JCI Accredition</a></li>
                        <li><a href="#">Ayurveda Hosital</a></li>
                        <li><a href="#">Parents Care Plan</a></li>
                        <li><a href="#">Blood Bank Setup</a></li>
                        <li><a href="#">Tele-Machine Services</a></li> -->

                    </ul>
                </div>
                <div class="col-lg-3 col-md-12 col-sm-12 footer-widget">
                    <h4 class="widget-title">Address</h4>
                    <ul class="address-widget">
                        <li>
                            <i class="flaticon-location"></i>
                            <div class="desc"> <a href="#" target="_blank">Muslim Street
Thengamputhur
TamilNadu,639602</div></a>
                        </li>
                        <li>
                            <i class="flaticon-call"></i>
                            <div class="desc">
                                <a href="tel:+91 99404 96796">+91-9940496796</a>

                            </div>
                        </li>
                        <li>
                            <i class="flaticon-email"></i>
                            <div class="desc">
                                <a href="mailto: "> info@gmail.com</a>

                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="row y-middle">

                <div class="col-lg-6 md-mb-20">
                    <div class="copyright text-center md-text-left">
                        <p>&copy; 2024 All Rights Reserved.</a></p>
                    </div>
                </div>
                <div class="col-lg-6 text-right md-text-left">
                    <ul class="footer-social">
                        <li><a href="#" target=_blank><i
                                    class="fa fa-facebook"></i></a></li>

                        <li><a href="#" target=_blank><i
                                    class="fa fa-instagram"></i></a></li>
                        <li><a href="#" target=_blank><i
                                    class="fa fa-linkedin"></i></a></li>

                    </ul>
                </div>
            </div>
        </div>
    </div>

</footer>
<div class="footer_bottom ">

    <div class="box box_right">
        <a href="tel:+91 99404 96796"  target="_blank" style="padding: 5px;
            width: 63px;
            margin: 6px;position: relative;
            top: -58px;
            "><i class="fa fa-phone"></i> </a>
    </div>
</div>
<!-- End scrollUp  -->

<div class="footer_bottom ">
    <div class="box">
        <a href="https://wa.me/+919940496796" target="_blank"><i class="fa fa-whatsapp"></i></a>
    </div>

</div>