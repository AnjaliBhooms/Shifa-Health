<!--Full width header Start-->
<div class="full-width-header header-style1 home1-modifiy">
    <!--Header Start-->
    <header id="rs-header" class="rs-header">
        <!-- Topbar Area Start -->
        <div class="topbar-area dark-parimary-bg">
            <div class="container">
                <div class="row y-middle">
                    <div class="col-md-7">
                        <ul class="topbar-contact">
                            <li class="btn-part">

                                <a class="apply-btn" href="#"><img src="assets/image/logo/chat.png"style="width:20px">Support Team Chat</a>
                            </li>
                            <li class="btn-part">

                                <a class="apply-btn" href="tel: +91 99404 96796"><img src="assets/image/logo/call.png" style="width:20px"> +91-9940496796</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-5 text-right">
                        <ul class="topbar-right">
                            <li class="login-register">
                                <a href="mailto: info@shifahealth.com"><img src="assets/image/logo/email.png " style="width:35px"></a>
                                <!-- <a href="login.html">Login</a> -->
                                <a href="https://wa.me/+919940496796"><img src="assets/image/logo/whatsapp.png " style="width:35px"></a>
                               <a href="#"> <img src="assets/image/logo/facebook.png " style="width:35px"></a>
                                <a href="#"><img src="assets/image/logo/instagram.png " style="width:35px"></a>
                            </li>
                            <!-- <li>
                                <a class="apply-btn" href="apply.php">Apply Now</a>
                            </li> -->
                        </ul>
                    </div>
                </div>
            </div>
        </div>
      

        <!-- Menu Start -->
        <div class="menu-area menu-sticky">
            <div class="container">
                <div class="row y-middle">
                    <div class="col-lg-2">
                        <div class="logo-cat-wrap">
                            <div class="logo-part">
                                <a href="index.php">
                                    <img src="assets/image/logo/logo.jpg" alt="">
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-10 text-right" style="margin-top: -16px">
                        <div class="rs-menu-area">
                            <div class="main-menu">
                                <div class="mobile-menu">
                                    <a class="rs-menu-toggle">
                                        <i class="fa fa-bars"></i>
                                    </a>
                                </div>
                                <nav class="rs-menu">
                                    <ul class="nav-menu">
                                        <li class=" mega-rs menu-item current-menu-item"> <a href="index.php">Home</a>

                                        </li>
                                        <li class="menu-item">
                                            <a href="about.php">About</a>

                                        </li>
                                        <li class="menu-item-has-children">
                                            <a href="">Service</a>
                                            <ul class="sub-menu">

                                                <li class="menu-item">
                                                    <a href="">ICU Setup</a>
                                                </li>
                                                <li class="menu-item">
                                                    <a href="">Medical Staff Solution</a>

                                                </li>
                                                <li class="menu-item">
                                                    <a href="">Hospital Project Upgradation</a>

                                                </li>
                                                <li class="menu-item">
                                                    <a href="">Doctor srvices</a>

                                                </li>
                                                <li class="menu-item">
                                                    <a href="">Medical Equipment</a>

                                                </li>
                                                <li class="menu-item">
                                                    <a href="">NABl</a>

                                                </li>
                                                <li class="menu-item">
                                                    <a href="">NABH</a>

                                                </li>
                                                <li class="menu-item">
                                                    <a href="">JCI Accredition</a>

                                                </li>
                                                <li class="menu-item">
                                                    <a href="">Ayurveda Hospital</a>

                                                </li>
                                                <li class="menu-item">
                                                    <a href="">Parents Care Plan</a>

                                                </li>
                                                <li class="menu-item">
                                                    <a href="">Blood Bank Setup </a>

                                                </li>
                                                <li class="menu-item">
                                                    <a href="">Tele-Medicine Services</a>

                                                </li>
                                            </ul>

                                        </li>
                                        
                                        <li class="menu-item-has-children">
                                            <a href="#">Segments</a>
                                            <ul class="sub-menu">

                                                <li class="menu-item">
                                                    <a href="#">Project Upgradation</a>
                                                   
                                                </li>
                                                <li class="menu-item">
                                                    <a href="#">HR</a>
                                                   

                                                </li>
                                                
                                            </ul>
                                        </li>


                                        <li class="menu-item">
                                            <a href="#">Clients</a>

                                        </li>


                                        <li class="menu-item">
                                            <a href="contact.php">Contact Us</a>

                                        </li>
                                        
                                    </ul> <!-- //.nav-menu -->
                                </nav>
                            </div> <!-- //.main-menu -->
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- Menu End -->
    </header>
    <!--Header End-->
</div>
<!--Full width header End-->
<!-- 
   <div class="njs-sticky-side body-append image_button_cover placement-right now-show" >
<a href=""><img src="assets/image/job-search.png" style="padding: 5px;
  width: 63px;
  margin: 6px; background-color: white;"></a>
</div> -->
<!-- social media  start-->

<!-- social media  end-->


<style>
    @media only screen and (max-width: 600px) {
        .sidebar-social-media {
            flex-direction: column;
            align-items: center;
        }
    }
</style>
